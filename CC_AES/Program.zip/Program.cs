﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;



namespace CC_AES
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 3)
            {
                System.Console.WriteLine("Please enter InputFrame Kmac Kenc");
            }

            //conversion des arguments
            string input_frame = args[0];
            byte[] kmacbytes = Hex2Bytes(args[1].Substring(0, 32));
            byte[] kencbytes = Hex2Bytes(args[2].Substring(0, 32));


            //Décodage trame
            string lblCRC = input_frame.Substring(input_frame.Length - 4, 4);
            string lblMField = input_frame.Substring(4, 4);
            string lblAField = input_frame.Substring(8, 12);
            string lblClField = input_frame.Substring(20, 2);       
            int cfield = Int32.Parse(input_frame.Substring(2, 2), System.Globalization.NumberStyles.HexNumber);
            string lblCField = cfield.ToString("X2");

            //System.Console.WriteLine("lblCRC " + lblCRC);

            // le CRC est à 0 si la trame est issue des flux WAN (le concentrateur remplace le CRC par 0, le check d'intégrité étant fait par le MLAN)
            if (lblCRC == "0000") 
            {
                //System.Console.WriteLine("lblCRC = 0000");
            }
            else
            {
                //calcul du CRC
                string CRCinput = input_frame.Substring(0, input_frame.Length - 4);
                byte[] CRCinputbytes = Hex2Bytes(CRCinput);
                short CRCcomputed = CLibCRC.CalculateCRC16EN13757(CRCinputbytes);
                string lblCRCFieldComment = CRCcomputed.ToString("X2");

                //vérification du CRC calculé et du CRC de la trame
                if (lblCRCFieldComment.ToString().ToUpper() == lblCRC.ToString().ToUpper())
                {
                    string CRCOK = "true";
                }
                else
                {
                    System.Console.WriteLine("Error CRC: CRC calculated = " + lblCRCFieldComment + " CRC in frame = " + lblCRC);

                }
            }


            //l6
            string l6 = input_frame.Substring(22, input_frame.Length - 26);

            string l6ctrl = Convert.ToString(byte.Parse(l6.Substring(0, 2), System.Globalization.NumberStyles.HexNumber), 2).PadLeft(8, '0');

            string lblL6Vers = l6ctrl.Substring(0, 3);
            string lblL6Wts = l6ctrl.Substring(3, 1);
            string lblL6KeySel = l6ctrl.Substring(4, 4);
            
            // System.Console.WriteLine("Clé n° : " + Convert.ToInt32(lblL6KeySel.ToString(), 2).ToString());

            //KMAC
            string lblL6Cpt = l6.Substring(2, 4);

            string lblL6HashKmac = l6.Substring(l6.Length - 4, 4);

            string Cmacinput = input_frame.Substring(0, input_frame.Length - 8);
            byte[] Cmacinputbytes = Hex2Bytes(Cmacinput);
            string lblL6HashKmacComment = Bytes2Hex(CAES128.AES_CMAC(Cmacinputbytes, kmacbytes), 2);
            if (lblL6HashKmacComment.ToString().ToUpper() == lblL6HashKmac.ToString().ToUpper())
            {
                lblL6HashKmacComment += " OK";
               // System.Console.WriteLine("KMAC OK");
            }
            else
            {
                lblL6HashKmacComment += " KO";
                 System.Console.WriteLine("KMAC NOK");

            }

            //L7
 
            string l7 = "";
            string Cencinput = "";
            string lblL6HashKenc;
            string lblL6TStampComment;
            string lblL6TStamp = "";


            if (lblL6Wts.ToString() == "1")
            {
                lblL6TStamp = l6.Substring(l6.Length - 8, 4);
                lblL6HashKenc = l6.Substring(l6.Length - 16, 8);
                Cencinput = input_frame.Substring(0, input_frame.Length - 20);
                l7 = l6.Substring(6, l6.Length - 22);
            }
            else
            {
                lblL6TStamp = "";
                lblL6TStampComment = "Absent";
                lblL6HashKenc = l6.Substring(l6.Length - 12, 8);
                Cencinput = input_frame.Substring(0, input_frame.Length - 16);
                l7 = l6.Substring(6, l6.Length - 18);
            }

            byte[] Cencinputbytes = Hex2Bytes(Cencinput);
            string lblL6HashKencComment = Bytes2Hex(CAES128.AES_CMAC(Cencinputbytes, kencbytes), 4);
            if (lblL6HashKencComment.ToString().ToUpper() == lblL6HashKenc.ToString().ToUpper())
            {
                lblL6HashKencComment += " OK";
                // System.Console.WriteLine("KENC OK");
            }
            else
            {
                lblL6HashKencComment += " KO";
                System.Console.WriteLine("KENC NOK");
            }

               string txtIV = (lblMField.ToString() + lblAField.ToString() + lblL6Cpt.ToString() + lblCField.ToString()).PadRight(32, '0');
                           // System.Console.WriteLine("txtIV " + txtIV);


                byte[] l7decipheredbytes = CAES128.AES_CTR(Hex2Bytes(l7), kencbytes, Hex2Bytes(txtIV));

                string l7deciphered = Bytes2Hex(l7decipheredbytes, l7decipheredbytes.Length);

                System.Console.WriteLine("L7 " + l7deciphered);


        }

        private static byte[] Hex2Bytes(string hex)
        {
            // On vérifie que la chaine a bien une longueur paire
            if (hex.Length % 2 != 0)
            {
                throw new ArgumentException("hex", "hex doit être de longueur paire");
            }

            // On traite les caractères 2 par 2 pour les transformer
            byte[] hexAsBytes = new byte[hex.Length / 2];
            for (int index = 0; index < hexAsBytes.Length; index++)
            {
                string byteValue = hex.Substring(index * 2, 2);
                hexAsBytes[index] = byte.Parse(byteValue, System.Globalization.NumberStyles.HexNumber, System.Globalization.CultureInfo.InvariantCulture);
            }

            return hexAsBytes;
        }

        private static string Bytes2Hex(byte[] data, int length)
        {
            string answer = "";
            int i = 0;
            while (i < length)
            {
                answer += data[i].ToString("X2");
                i++;
            }
            return answer;
        }
    }
}
